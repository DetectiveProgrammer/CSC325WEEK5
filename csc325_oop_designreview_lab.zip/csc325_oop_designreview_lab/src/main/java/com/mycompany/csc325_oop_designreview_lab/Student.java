
package com.mycompany.csc325_oop_designreview_lab;

/**
 *
 * @author MoaathAlrajab
 */
/**
 *
 * @author MoaathAlrajab
 */
public class Student extends Human{
    
    public Double gpa;

    
   public Student(String namea, int agea, Double gpa)
    {
        super(namea, agea);
        gpa = this.gpa;
             //constructor

        
    }
    public Student(double gpaA)
    {
        gpa = gpaA;
     //constructor
        
        
    }
    public Double getGpa() {
        return gpa;
        //returns gpa
    }

    public void setGpa(Double gpa) {
        this.gpa = gpa;
        //sets gpa
    }
	// ToDo 1: Make this class a child of Human
	
	// ToDo 2: Fix the resulting errors
	
	// ToDo 3: Add a field for GPA and create setter and getter
	
	// ToDo 4: Add comments to your code

}
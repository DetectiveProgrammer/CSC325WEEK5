/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.csc325_oop_designreview_lab;

/**
 *
 * @author itlabs
 */
public abstract class Senior extends Student{
    private int credits;
    public Senior(double gpab, int creditsa)
    {
        super(gpab);
        credits = creditsa;
             //constructor

    }
    
    public void setGpa(Double gpac) {
        gpa = gpac;
             //constructor

    }
     public String toString()
    {
        //returns message based on credit evaluation
        if(credits >= 85)
        {
            return "Appropiate amount of credits.";
        }
        
        else
        {
            return "Not enough credits";
        }
    }
    
    

}
